# TwitchFollowers(Twitch-Farmer)
Twitch Farmer is a bot that helps you to get more followers.
----------------------

WRITTEN BY (fastercoder)

# INSTALLATION

no token required
the bot token are already inside the .exe (tfollow.exe)
open tfollow.exe and enjoy your followers instant delivery 
  
  
